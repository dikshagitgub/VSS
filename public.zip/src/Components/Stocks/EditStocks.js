import React from "react";
import { Container, Col, Row, Modal } from "react-bootstrap";

const EditStocks = ({ match }) => {
  console.log(match);
  return (
    <div>
      <h1>Edit Stocks</h1>
    </div>
  );
};

export default EditStocks;
