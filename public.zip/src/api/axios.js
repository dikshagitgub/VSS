import axios from "axios";

export default axios.create({
  baseURL: "http://3.110.171.168",
});
